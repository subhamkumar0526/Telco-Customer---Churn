# Customer Churn Prediction (Streamlit)

Files
- app.py                      -> Streamlit app (Single / Batch / Insights)
- final_gb_classifier.pkl     -> trained Gradient Boosting model
- Telco-Customer-Churn.csv    -> dataset
- Customer_chrun_project.ipynb-> training notebook
- requirements.txt

Run
    pip install -r requirements.txt
    streamlit run app.py

Keep all files in the same folder.
